Zip fajl IbusDevices.zip
========================
Sadrzi projekat za Ibus Control Panel, IbusNtDll i setup projekte za 32 i 64 bita.
Raspakovati ga na virtualnoj masini u folder C:\Projekti\CU906, kako bi radilo kompajliranje sa Visual Studio 2008.

Zip faj gnudll.zpi
==================
gnudll.dll fajl koji komunicira sa gnu-om.
On moze biti raspakovan bilo gde i trazi Visual Studio 2019
