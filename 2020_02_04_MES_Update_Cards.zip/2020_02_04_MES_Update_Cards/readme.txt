Instalacija update-a za citace kartica
=========================================

1. Zaustaviti mes_prn.ex pomocu ikonice u tray bar-u.
2. Zaustaviti service "MES Card Reader Service" (MESCard). Preko "Services" aplikacije ili u administrativnom command prompt-u komandom "net stop MESCard".
3. Iskopirati fajlove mes_prn.exe i MESCardService.exe u odogovarajuci folder (C:\MESPrint ili tako nesto nisam siguran da je svuda isto, uglavnom tamo gde je mes_prn.exe i MESCardService.exe)
4. Pokrenuti service "MES Card Reader Service" (MESCard)
5. Pokrenuti aplikaciju mes_prn.exe (dupli klik na exe)
6. Proveriti rad citaca kartica, najlakse je pomocu notepad-a (dok je u fokusu provuci karticu, broj koji se ispise bi trebalo da bude jednak onom ispisanom na kartici)
7. Ulogovati se kao operater i OBAVEZNO probati automatsku stampu uz pomoc funkcionalnosti MES-a stampa deklaracije
